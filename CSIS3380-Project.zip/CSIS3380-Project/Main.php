<?php

require_once("inc/config.inc.php");
require_once("inc/Entities/User.class.php");
require_once("inc/Entities/Album.class.php");
require_once("inc/Entities/Post.class.php");
require_once("inc/Utilities/Page.class.php");
require_once("inc/Utilities/PDOAgent.class.php");
require_once("inc/Utilities/UserDAO.class.php");
require_once("inc/Utilities/AlbumDAO.class.php");
require_once("inc/Utilities/PostDAO.class.php");


session_start();

if(isset($_POST["logout"]))
{
    session_destroy();
    header("location:Login.php");
}
  else if(isset($_SESSION)&&$_SESSION["loggedin"])
  {
        AlbumDAO::init();
        UserDAO::init();
        $userid = UserDAO::getUser($_SESSION["username"])->getUserID();
        if(isset($_POST["addbtn"]))
        {

        }

        if(isset($_POST["createbtn"]))
        {
            if(!empty($_POST["newalbumname"]))
            {
                $newalbum = New Album();
                $newalbum->setAlbumName($_POST["newalbumname"]);
                $newalbum->setUserID($userid);
                var_dump($newalbum);
                AlbumDAO::createAlbum($newalbum);
            }
        }
        if(isset($_POST["showAlbum"]))
            {
                header("location:Album.php");
            }
            else
            {
                Page::header();
                Page::mainpage();
                if(isset($_POST["addtoAlbum"]))
                {
                    $albums = AlbumDAO::getAlbums($userid);
                    Page::addimageform($albums);
                }
                if(isset($_POST["createAlbum"]))
                {
                    Page::createalbum();
                }
                Page::footer();
            }
    }
    else{
        session_destroy();
        header("location:Login.php");
    }
        

?>