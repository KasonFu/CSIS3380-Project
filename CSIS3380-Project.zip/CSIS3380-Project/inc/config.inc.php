<?php

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_NAME','Projectdb');
define('DB_PASS','');
## You may not change the API_URL it must map to your API, you will have to change your web server alias
define('API_URL','')

?>