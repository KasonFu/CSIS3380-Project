<?php

class Page  {

    public static $title = "Set Title!";

    static function header()    { ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Group Project</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100">

			
	
    <?php }

    static function footer()    { ?>

        </div>
                </div>
            </div>
        <!--===============================================================================================-->
        <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
        <!--===============================================================================================-->
            <script src="vendor/animsition/js/animsition.min.js"></script>
        <!--===============================================================================================-->
            <script src="vendor/bootstrap/js/popper.js"></script>
            <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <!--===============================================================================================-->
            <script src="vendor/select2/select2.min.js"></script>
        <!--===============================================================================================-->
            <script src="vendor/daterangepicker/moment.min.js"></script>
            <script src="vendor/daterangepicker/daterangepicker.js"></script>
        <!--===============================================================================================-->
            <script src="vendor/countdowntime/countdowntime.js"></script>
        <!--===============================================================================================-->
            <script src="js/main.js"></script>

</body>
</html>
    <?php
    } 
        static function showlogin(){    ?>
    
            <form action="" method = "POST" class="login100-form validate-form">
                            <span class="login100-form-logo">
                                <i class="zmdi zmdi-landscape"></i>
                            </span>

                            <span class="login100-form-title p-b-34 p-t-27">
                                Log in
                            </span>

                            <div class="wrap-input100 validate-input" data-validate = "Enter username">
                                <input class="input100" type="text" name="username" placeholder="Username">
                                <span class="focus-input100" data-placeholder="&#xf207;"></span>
                            </div>

                            <div class="wrap-input100 validate-input" data-validate="Enter password">
                                <input class="input100" type="password" name="password" placeholder="Password">
                                <span class="focus-input100" data-placeholder="&#xf191;"></span>
                            </div>

                            <div class="container-login100-form-btn">
                                <input class="login100-form-btn" type="submit" value="Log in">
                            </div>

                        </form>

    <?php }

        static function mainpage()
        {?>
        <form class="login100-form validate-form" action="" method = "POST">
        <input class="login100-form-btn" type="submit" name = "addtoAlbum" value = "Add into Exist Ambum">
        <input class="login100-form-btn" type="submit" name = "createAlbum" value = "Create New Album">
        <input class="login100-form-btn" type="submit" name = "deleteAlbum" value = "Delete your Albums">
        <input class="login100-form-btn" type="submit" name = "updateAlbum" value = "Edit your Albums">
        <input class="login100-form-btn" type="submit" name = "showAlbum" value = "Show my Album">
        <input class="login100-form-btn" type="submit" name = "logout" value = "Log out">
        </form>
        <?php 
    }

        static function addimageform($albums)
        {?>
            <form method = "POST" action = "" class="login100-form validate-form">
            <h6>Which album do you want to add this image?</h6>
            <?php
            foreach($albums as $album)
            {?>
            <input type = "radio" name = "addradio" value = <?php echo $album->getAlbumID();?>><?php echo $album->getAlbumName();?>    
            <?php 
            }?>
            <input class="login100-form-btn" type = "submit" name ="addbtn" value ="Add">
            </form>
        <?php }


        static function createalbum()
                {?>
                    <h1>Create New Album</h1>
                    <form method = "POST" action = "" class="login100-form validate-form">
                    <label for="newalbumname" value = "Album Name">
                    <input type = "input" name = "newalbumname">
                    <input class="login100-form-btn" type = "submit" name ="createbtn" value ="Create">
                    </form>
                    
        <?php }

        static function albumpage($Albums)
        {?>
            <form method = "POST" action = "" class="login100-form validate-form">
            <TABLE>
            <TR>
            <TD>Your Albums:</TD>
            </TR>
        <?php 
            if(count($Albums) == 0)
            {?>
               <TR><TD> You have no album currently</TD></TR>
                <TR><TD>You can create your albums in previous page</TD><TR>
        <?php }
            foreach($Albums as $Album)
            {?>

                <TR>
                <TD>
                <input type = "radio" name = "albumid" value =<?php echo $Album->getAlbumID();?>><?php echo $Album->getAlbumName();?>
                </TD>
                </TR><?php
            }?> 
            </TABLE>
            <input class="login100-form-btn" type = "submit" name ="showalbum" value = "Check Album">
            </form>
            <form class="login100-form validate-form" action="" method = "POST">
            <input class="login100-form-btn" type = "submit" name ="back" value = "Go back">
            <input class="login100-form-btn" type="submit" name = "logout"value="Log out">
            </form>
       <?php
        }

        static function showimages($AlbumID)
        {
            $Album = AlbumDAO::getAlbum($AlbumID);
            echo "This is Album: ".$Album->getAlbumName();
            $posts = PostDAO::getPosts($AlbumID);
            echo "<Table>";
            if(count($posts) == 0)
            {?>
                <TR><TD>You have no image in this album.<TD></TR>
            <?php }
            foreach($posts as $post)
            {
            ?>
            <TR><TD><img src=<?php echo $post->getImageURL();?> ><TD></TR>
    <?php
            }
            echo "</Table>";
        }
}

?>