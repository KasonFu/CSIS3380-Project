<?php

class AlbumDAO   {

    //Store the PDO agent here.
    private static $db;

    static function init()  {
        //Initialize the internal PDO Agent
        self::$db = new PDOAgent("Album");
    }


    static function getAlbum($albumid)  {

        $sqlQuery = "SELECT * FROM album WHERE albumid = :albumid";
        //Query!
        self::$db->query($sqlQuery);
        self::$db->bind(':albumid',$albumid);
        //Execute!
        self::$db->execute();
        //Return the reuslts!
        return self::$db->singleResult();
    }

    static function getAlbums($userid)  {

        $sqlQuery = "SELECT * FROM album where userid = $userid;";
        //Query!
        self::$db->query($sqlQuery);
        //Bind!
        //Execute!
        self::$db->execute();
        //Return the reuslts!
        return self::$db->resultSet();
    }
    
    static function createAlbum(Album $a)  {

        $sqlInsert = "INSERT INTO album (albumname, userid)
            VALUES (:albumname, :userid);";
        //Query!
        self::$db->query($sqlInsert);
        //Bind!
        self::$db->bind(':albumname',$a->getAlbumName());
        self::$db->bind(':userid',$a->getUserID());
        //Execute!
        self::$db->execute();
        //Return the reuslts!
        
        return  self::$db->lastInsertId();

    }

    
    
}